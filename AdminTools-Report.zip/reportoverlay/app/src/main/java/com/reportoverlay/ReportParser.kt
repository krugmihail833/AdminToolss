package com.reportoverlay

data class Report(val nick: String, val id: String, val text: String)

object ReportParser {

    // Строка чата начинается с времени вида 09:49
    private val TIME = Regex("^\\s*\\d{1,2}\\s*[:.]\\s*\\d{2}\\s*")

    // Ник[ID]: текст [К-во репорта: N]
    private val REPORT = Regex(
        "([A-Za-z0-9_]{3,})\\s*[\\[({|]\\s*(\\d{1,4})\\s*[\\])}|]\\s*:\\s*(.+?)\\s*" +
            "[\\[({|]\\s*[КкKk]\\s*[-–—~]?\\s*[вВBb][оОoO].*$"
    )

    fun parse(raw: String): List<Report> {
        val lines = raw.lines().map { it.trim() }.filter { it.isNotEmpty() }

        // Длинные сообщения переносятся без времени — склеиваем с предыдущей строкой
        val merged = ArrayList<String>()
        for (l in lines) {
            if (merged.isEmpty() || TIME.containsMatchIn(l)) merged.add(l)
            else merged[merged.size - 1] = merged.last() + " " + l
        }

        val result = ArrayList<Report>()
        for (m in merged) {
            val s = TIME.replaceFirst(m, "").trim()
            // Служебные строки (<ADM> ... ответил ...) пропускаем
            if (s.startsWith("<") || s.startsWith("(") || s.startsWith("«")) continue
            val g = REPORT.find(s) ?: continue
            val text = g.groupValues[3].trim()
            if (text.isEmpty()) continue
            result.add(Report(g.groupValues[1], g.groupValues[2], text))
        }
        return result
    }

    fun key(r: Report): String {
        val norm = r.text.lowercase().filter { it.isLetterOrDigit() }.take(25)
        return r.id + "|" + norm
    }
}
