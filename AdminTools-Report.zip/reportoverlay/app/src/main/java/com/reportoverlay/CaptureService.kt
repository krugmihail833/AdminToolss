package com.reportoverlay

import android.app.Activity
import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.Service
import android.content.Context
import android.content.Intent
import android.content.pm.ServiceInfo
import android.graphics.Bitmap
import android.graphics.PixelFormat
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.Build
import android.os.Handler
import android.os.HandlerThread
import android.os.IBinder
import android.os.VibrationEffect
import android.os.Vibrator
import android.content.res.Resources
import com.googlecode.tesseract.android.TessBaseAPI
import java.io.File

/** Раз в пару секунд снимает экран, распознаёт область чата и ищет репорты. */
class CaptureService : Service() {

    companion object {
        const val ACTION_STOP = "com.reportoverlay.STOP"
        private const val CHANNEL = "capture"
    }

    private var projection: MediaProjection? = null
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private var thread: HandlerThread? = null
    private var handler: Handler? = null
    private var tess: TessBaseAPI? = null

    private val lastSeen = HashMap<String, Long>()
    private var scans = 0

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent == null || intent.action == ACTION_STOP) {
            stopSelf()
            return START_NOT_STICKY
        }
        startFg()
        cleanup()

        val code = intent.getIntExtra("code", Activity.RESULT_CANCELED)
        @Suppress("DEPRECATION")
        val data: Intent? = intent.getParcelableExtra("data")
        if (code != Activity.RESULT_OK || data == null) {
            Debug.status = "нет разрешения на запись экрана"
            stopSelf()
            return START_NOT_STICKY
        }

        val t = HandlerThread("ocr").also { it.start() }
        thread = t
        val h = Handler(t.looper)
        handler = h

        val mpm = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        val proj = mpm.getMediaProjection(code, data)
        projection = proj
        proj.registerCallback(object : MediaProjection.Callback() {
            override fun onStop() {
                Debug.status = "запись экрана остановлена системой"
                stopSelf()
            }
        }, h)

        // Игра идёт в ландшафте, поэтому снимаем «широкую» картинку
        val dm = Resources.getSystem().displayMetrics
        val w = maxOf(dm.widthPixels, dm.heightPixels)
        val hh = minOf(dm.widthPixels, dm.heightPixels)
        val r = ImageReader.newInstance(w, hh, PixelFormat.RGBA_8888, 2)
        reader = r
        display = proj.createVirtualDisplay(
            "report-capture", w, hh, dm.densityDpi,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            r.surface, null, h
        )

        h.post { initOcrAndLoop() }
        Debug.status = "запуск..."
        return START_NOT_STICKY
    }

    private fun startFg() {
        val nm = getSystemService(Context.NOTIFICATION_SERVICE) as NotificationManager
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL, "Слежение за репортами", NotificationManager.IMPORTANCE_LOW)
        )
        val n = Notification.Builder(this, CHANNEL)
            .setContentTitle("Слежение за репортами")
            .setContentText("Приложение читает область чата")
            .setSmallIcon(android.R.drawable.ic_dialog_info)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION)
        } else {
            startForeground(1, n)
        }
    }

    private fun initOcrAndLoop() {
        try {
            val dir = File(filesDir, "tessdata").also { it.mkdirs() }
            for (n in listOf("rus.traineddata", "eng.traineddata")) {
                val f = File(dir, n)
                if (!f.exists() || f.length() == 0L) {
                    assets.open("tessdata/$n").use { i -> f.outputStream().use { o -> i.copyTo(o) } }
                }
            }
            val api = TessBaseAPI()
            if (!api.init(filesDir.absolutePath, "rus+eng")) {
                Debug.status = "не удалось запустить распознавание"
                stopSelf()
                return
            }
            api.setPageSegMode(TessBaseAPI.PageSegMode.PSM_SINGLE_BLOCK)
            tess = api
            Debug.status = "работает"
            loop()
        } catch (e: Throwable) {
            Debug.status = "ошибка запуска: $e"
            stopSelf()
        }
    }

    private fun loop() {
        val h = handler ?: return
        val interval = getSharedPreferences("cfg", MODE_PRIVATE).getInt("interval", 1500).toLong()
        try {
            scan()
        } catch (e: Throwable) {
            Debug.status = "ошибка: $e"
        }
        h.postDelayed({ loop() }, interval)
    }

    private fun scan() {
        val rd = reader ?: return
        val api = tess ?: return
        val prefs = getSharedPreferences("cfg", MODE_PRIVATE)
        val img = rd.acquireLatestImage() ?: return

        val crop: Bitmap
        try {
            val plane = img.planes[0]
            val pw = plane.rowStride / plane.pixelStride
            val full = Bitmap.createBitmap(pw, img.height, Bitmap.Config.ARGB_8888)
            full.copyPixelsFromBuffer(plane.buffer)

            val iw = img.width
            val ih = img.height
            val l = prefs.getInt("left", 22).coerceIn(0, 95)
            val t = prefs.getInt("top", 0).coerceIn(0, 95)
            val rr = prefs.getInt("right", 68).coerceIn(l + 3, 100)
            val b = prefs.getInt("bottom", 30).coerceIn(t + 3, 100)
            val x = iw * l / 100
            val y = ih * t / 100
            val cw = maxOf(10, iw * rr / 100 - x).coerceAtMost(iw - x)
            val ch = maxOf(10, ih * b / 100 - y).coerceAtMost(ih - y)
            crop = Bitmap.createBitmap(full, x, y, cw, ch)
            full.recycle()
        } finally {
            img.close()
        }

        val prepared = prepare(crop)
        crop.recycle()
        api.setImage(prepared)
        val text = api.getUTF8Text() ?: ""
        api.clear()
        prepared.recycle()

        Debug.lastText = text
        Debug.scans = ++scans

        val reports = ReportParser.parse(text)
        val now = System.currentTimeMillis()
        val warmup = scans <= 2
        for (rep in reports) {
            val key = ReportParser.key(rep)
            val prev = lastSeen[key]
            lastSeen[key] = now
            val isNew = prev == null || now - prev > 120_000
            if (isNew && !warmup) {
                onNewReport(rep)
            }
        }
        // чистим старые ключи
        lastSeen.entries.removeAll { now - it.value > 15 * 60_000 }
    }

    /** Оставляем только цвета текста репортов (жёлтый/оранжевый/красный) и белый, делаем чёрным на белом. */
    private fun prepare(src: Bitmap): Bitmap {
        val scale = (600f / src.height).coerceIn(1f, 3f)
        val s = if (scale > 1.05f) {
            Bitmap.createScaledBitmap(src, (src.width * scale).toInt(), (src.height * scale).toInt(), true)
        } else src
        val w = s.width
        val h = s.height
        val px = IntArray(w * h)
        s.getPixels(px, 0, w, 0, 0, w, h)
        for (i in px.indices) {
            val c = px[i]
            val r = (c shr 16) and 255
            val g = (c shr 8) and 255
            val b = c and 255
            val isText = minOf(r, g, b) > 205 || (r > 170 && b < 120 && r - b > 90)
            px[i] = if (isText) 0xFF000000.toInt() else 0xFFFFFFFF.toInt()
        }
        val out = Bitmap.createBitmap(w, h, Bitmap.Config.ARGB_8888)
        out.setPixels(px, 0, w, 0, 0, w, h)
        if (s !== src) s.recycle()
        return out
    }

    private fun onNewReport(r: Report) {
        try {
            val v = getSystemService(Context.VIBRATOR_SERVICE) as Vibrator
            v.vibrate(VibrationEffect.createOneShot(150, VibrationEffect.DEFAULT_AMPLITUDE))
        } catch (_: Throwable) {
        }
        OverlayWindow.get(this).show(r)
    }

    private fun cleanup() {
        handler?.removeCallbacksAndMessages(null)
        try { display?.release() } catch (_: Throwable) {}
        try { reader?.close() } catch (_: Throwable) {}
        try { projection?.stop() } catch (_: Throwable) {}
        try { tess?.recycle() } catch (_: Throwable) {}
        thread?.quitSafely()
        display = null; reader = null; projection = null; tess = null; thread = null; handler = null
    }

    override fun onDestroy() {
        cleanup()
        OverlayWindow.get(this).hide()
        if (Debug.status == "работает") Debug.status = "остановлено"
        super.onDestroy()
    }
}
