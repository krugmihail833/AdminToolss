package com.reportoverlay

/**
 * Тексты и команды окна репорта и клавиатуры.
 * %ID% заменяется на ID игрока. Ответы игроку уходят как: /pm ID текст
 * Основные тексты лежат в Defaults.kt (перенесены из прежней клавиатуры).
 */
object Phrases {

    /** Кнопка «Уточните» */
    const val CLARIFY = "Приветствую, уточните Ваш вопрос/жалобу"

    /** Оффтоп → «Предупредить» */
    const val OFFTOP_WARN = "Приветствую, при последующем оффтопе последует мут репорта"

    /** Оффтоп → «Наказать» (команда целиком, без /pm) */
    const val OFFTOP_PUNISH = "/rmute %ID% 20"

    private fun lines(s: String) = s.lines().map { it.trim() }.filter { it.isNotEmpty() }

    /** Быстрые ответы, столбец «Начало». */
    val QUICK_START: List<String> = lines(Defaults.QUICK_START)

    /** Быстрые ответы, столбец «Результат / Конец». */
    val QUICK_END: List<String> = lines(Defaults.QUICK_END)

    /** Частые команды (вкладка «Команды»). */
    val COMMANDS: List<String> = lines(Defaults.COMMANDS).map { it.replace("{id}", "%ID%") }

    /** Наказания по таблице правил сервера. */
    val PUNISHMENTS: List<Punish> = Punishments.parseMain(Defaults.MAIN_TABLE)

    /** Наказания FamWar. */
    val FAMWAR: List<Punish> = Punishments.parseFamWar(Defaults.FAMWAR_TABLE)

    /** Подставляет ID; если ID нет — команда вставляется без номера. */
    fun fill(template: String, id: String): String {
        val s = if (id.isBlank()) {
            template.replace(" %ID%", "").replace("%ID% ", "").replace("%ID%", "")
        } else {
            template.replace("%ID%", id)
        }
        return s.trim()
    }
}
